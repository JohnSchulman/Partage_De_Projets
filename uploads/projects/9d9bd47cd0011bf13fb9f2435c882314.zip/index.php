<?php

echo "test";

echo "<br><a href="page2.php">Page 2</a>";